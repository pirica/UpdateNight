
# Update Night

Update Night is a simple-to-use fortnite leaking tool with a tons of features

## Features

- Download files from Manifest
- Grabs lastest AES and Mappings
- Extract cosmetics (and make a collage of them)
- Extract the current Map
- Extract UI icons

## TODO

- Optimize code
- Add :
- - Challenges
- - Weapons
- - Consumables
- - BattlePass
- - Map with POIs
- Maybe Add (aka low priority) :
- - XP Coins in map
- - NPC Locations and quests
