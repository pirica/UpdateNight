using UpdateNight.TocReader.Parsers.Objects;

namespace UpdateNight.TocReader.IO
{
    public class FImportDesc
    {
        public FName Name;
        public FPackageObjectIndex GlobalImportIndex;
        public FExportDesc Export;
    }
}