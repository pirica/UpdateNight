namespace UpdateNight.TocReader.Parsers.Objects
{
    public enum EAnimationKeyFormat : byte
    {
        AKF_ConstantKeyLerp,
        AKF_VariableKeyLerp,
        AKF_PerTrackCompression,
        AKF_MAX,
    }
}
