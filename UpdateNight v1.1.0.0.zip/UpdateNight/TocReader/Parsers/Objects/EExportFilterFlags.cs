namespace UpdateNight.TocReader.Parsers.Objects
{
    public enum EExportFilterFlags : byte
    {
        None,
        NotForClient,
        NotForServer
    }
}