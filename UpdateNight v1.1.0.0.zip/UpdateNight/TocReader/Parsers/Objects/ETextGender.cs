namespace UpdateNight.TocReader.Parsers.Objects
{
    public enum ETextGender : byte
    {
        Masculine,
        Feminine,
        Neuter,
        // Add new enum types at the end only! They are serialized by index.
    }
}
