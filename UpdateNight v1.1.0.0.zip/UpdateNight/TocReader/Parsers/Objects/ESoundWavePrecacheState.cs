namespace UpdateNight.TocReader.Parsers.Objects
{
    /** Precache states */
    public enum ESoundWavePrecacheState
    {
        NotStarted,
        InProgress,
        Done
    }
}
