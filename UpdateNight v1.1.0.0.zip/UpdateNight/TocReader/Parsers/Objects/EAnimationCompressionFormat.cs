namespace UpdateNight.TocReader.Parsers.Objects
{
    public enum EAnimationCompressionFormat
    {
		ACF_None,
		ACF_Float96NoW,
		ACF_Fixed48NoW,
		ACF_IntervalFixed32NoW,
		ACF_Fixed32NoW,
		ACF_Float32NoW,
		ACF_Identity,
		ACF_MAX,
	}
}
