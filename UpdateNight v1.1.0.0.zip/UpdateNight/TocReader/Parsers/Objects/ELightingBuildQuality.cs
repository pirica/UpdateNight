namespace UpdateNight.TocReader.Parsers.Objects
{
    public enum ELightingBuildQuality
    {
        Preview,
        Medium,
        High,
        Production,
        MAX,
    }
}
