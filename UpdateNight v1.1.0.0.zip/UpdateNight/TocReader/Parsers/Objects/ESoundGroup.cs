namespace UpdateNight.TocReader.Parsers.Objects
{
    public enum ESoundGroup
    {
		Default,
		Effects,
		UI,
		Music,
		Voice,

		GameSoundGroup1,
		GameSoundGroup2,
		GameSoundGroup3,
		GameSoundGroup4,
		GameSoundGroup5,
		GameSoundGroup6,
		GameSoundGroup7,
		GameSoundGroup8,
		GameSoundGroup9,
		GameSoundGroup10,
		GameSoundGroup11,
		GameSoundGroup12,
		GameSoundGroup13,
		GameSoundGroup14,
		GameSoundGroup15,
		GameSoundGroup16,
		GameSoundGroup17,
		GameSoundGroup18,
		GameSoundGroup19,
		GameSoundGroup20,
	}
}
