namespace UpdateNight.TocReader.Parsers.Objects
{
    // Used to signify if it is used in UScriptStruct binary serialization
    public interface IUStruct { }
}
