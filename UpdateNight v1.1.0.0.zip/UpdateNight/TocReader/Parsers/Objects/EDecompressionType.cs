namespace UpdateNight.TocReader.Parsers.Objects
{
    public enum EDecompressionType
    {
		Setup,
		Invalid,
		Preview,
		Native,
		RealTime,
		Procedural,
		Xenon,
		Streaming,
		MAX,
	}
}
