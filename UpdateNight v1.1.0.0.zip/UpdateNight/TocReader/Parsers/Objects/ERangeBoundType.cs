namespace UpdateNight.TocReader.Parsers.Objects
{
    public enum ERangeBoundType
    {
        RangeExclusive,
        RangeInclusive,
        RangeOpen,
    }
}
